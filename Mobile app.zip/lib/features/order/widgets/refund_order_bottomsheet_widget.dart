import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:six_pos/common/widgets/custom_asset_image_widget.dart';
import 'package:six_pos/common/widgets/custom_button_widget.dart';
import 'package:six_pos/common/widgets/custom_text_field_widget.dart';
import 'package:six_pos/features/order/controllers/order_controller.dart';
import 'package:six_pos/features/splash/controllers/splash_controller.dart';
import 'package:six_pos/helper/extension_helper.dart';
import 'package:six_pos/helper/responsive_helper.dart';
import 'package:six_pos/helper/show_custom_snackbar_helper.dart';
import 'package:six_pos/util/dimensions.dart';
import 'package:six_pos/util/images.dart';
import 'package:six_pos/util/styles.dart';


class RefundOrderBottomSheetWidget extends StatefulWidget {
  final int? orderId;
  const RefundOrderBottomSheetWidget({super.key, required this.orderId});

  @override
  State<RefundOrderBottomSheetWidget> createState() => _RefundOrderBottomSheetWidgetState();
}

class _RefundOrderBottomSheetWidgetState extends State<RefundOrderBottomSheetWidget> {
  final TextEditingController _refundAmountController = TextEditingController();
  final TextEditingController _refundCauseController = TextEditingController();

  @override
  void initState() {
    _refundAmountController.text = (Get.find<OrderController>().orderDetail?.orderTotal ?? '').toString();
    super.initState();
  }

  @override
  void dispose() {
    _refundAmountController.dispose();
    _refundCauseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: GetBuilder<OrderController>(builder: (orderController){
        return SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Padding(
              padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall,right: Dimensions.paddingSizeSmall,top: Dimensions.paddingSizeSmall),
              child: Column(mainAxisSize:MainAxisSize.min, children: [
                const CustomAssetImageWidget(Images.lineIconSvg),

                Align(alignment: Alignment.topRight,
                  child: InkWell(
                    onTap: ()=> Get.back(),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).hintColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(50),
                      ),
                      padding: const EdgeInsets.all(Dimensions.paddingSizeExtraSmall),

                      child: CustomAssetImageWidget(Images.crossIcon,height: 14,width: 14,color: context.customThemeColors.textColor),
                    ),
                  ),
                ),

                Text('order_refund'.tr,style: ubuntuBold.copyWith(fontSize: Dimensions.fontSizeLarge,color: context.customThemeColors.textColor)),
                const SizedBox(height: Dimensions.paddingSizeSmall),
              ]),
            ),

            Container(
              margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall, vertical: Dimensions.paddingSizeDefault),
              padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                  color: Theme.of(context).hintColor.withValues(alpha: 0.07)
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, spacing: Dimensions.paddingSizeDefault, children: [
                Text('${'refund_amount'.tr} (${Get.find<SplashController>().configModel?.currencySymbol})',style: ubuntuBold.copyWith(fontSize: Dimensions.fontSizeLarge,color: context.customThemeColors.textColor)),

                CustomTextFieldWidget(
                  controller: _refundAmountController,
                  inputType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$'))],
                  hintText: '${Get.find<SplashController>().configModel?.currencySymbol}0.00',
                ),

                Text('refund_cause'.tr,style: ubuntuBold.copyWith(fontSize: Dimensions.fontSizeLarge,color: context.customThemeColors.textColor)),

                CustomTextFieldWidget(
                  controller: _refundCauseController,
                  maxLines: 3,
                  maxLength: 100,
                  hintText: 'type_refund_note'.tr,
                ),
              ]),
            ),

            Row(children: [
              if(ResponsiveHelper.isTab(context))
                const Expanded(flex: 1, child: SizedBox()),

              Expanded(flex: 1,
                child: Container(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                  margin: ResponsiveHelper.isTab(context) ? const EdgeInsets.all(Dimensions.paddingSizeDefault) : null,
                  decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: ResponsiveHelper.isTab(context) ?BorderRadius.circular(Dimensions.paddingSizeSmall) : null,
                      boxShadow: [BoxShadow(
                          color: Theme.of(context).hintColor.withValues(alpha: 0.3),
                          offset: const Offset(0, -5),
                          blurRadius: 7
                      )]
                  ),
                  child: Row(children: [
                    Expanded(child: CustomButtonWidget(
                      buttonText: 'cancel'.tr,
                      buttonColor: Theme.of(context).colorScheme.error.withValues(alpha: 0.1),
                      borderColor: Theme.of(context).colorScheme.error.withValues(alpha: 0.1),
                      isBorder: true,
                      textColor: Theme.of(context).colorScheme.error,
                      isClear: true,
                      onPressed: ()=> Get.back(),
                    )),
                    const SizedBox(width: Dimensions.paddingSizeExtraLarge),

                    Expanded(
                      child: orderController.isLoading ?
                      const Center(child: CircularProgressIndicator()) :
                      CustomButtonWidget(
                        buttonText: 'submit'.tr,
                        onPressed: (){
                          try{
                            if(double.parse(_refundAmountController.text) <= 0){
                              showCustomSnackBarHelper('${'amount_should_be_greater_than'.tr} 0');
                            }else if(double.parse(_refundAmountController.text) > (orderController.orderDetail?.orderTotal ?? 0)){
                              showCustomSnackBarHelper('${'amount_should_be_less_than'.tr} ${orderController.orderDetail?.orderTotal ?? 0}');
                            }else{
                              orderController.sendRefundRequest(orderId: widget.orderId ?? -1, orderAmount: _refundAmountController.text.trim(), orderNote: _refundCauseController.text);

                            }

                          }catch(e){
                            showCustomSnackBarHelper('please_enter_amount'.tr);
                          }
                        },
                      ),
                    ),
                  ]),
                ),
              ),
            ]),
          ]),
        );
      }),
    );
  }
}
