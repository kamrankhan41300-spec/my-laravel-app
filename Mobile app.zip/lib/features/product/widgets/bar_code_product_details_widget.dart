import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:six_pos/common/models/product_model.dart';
import 'package:six_pos/common/widgets/custom_image_widget.dart';
import 'package:six_pos/features/splash/controllers/splash_controller.dart';
import 'package:six_pos/helper/responsive_helper.dart';
import 'package:six_pos/util/dimensions.dart';
import 'package:six_pos/util/images.dart';
import 'package:six_pos/util/styles.dart';

class BarCodeProductDetailsWidget extends StatelessWidget {
  final Products? product;
  final Color? backgroundColor;

  const BarCodeProductDetailsWidget({super.key, this.product, this.backgroundColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall, horizontal: Dimensions.paddingSizeDefault),
      decoration: BoxDecoration(
          color: backgroundColor ?? Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(ResponsiveHelper.isTab(context) ? Dimensions.paddingSizeSmall : 0),
          boxShadow: [BoxShadow(blurRadius: 5, color: Theme.of(context).primaryColor.withValues(alpha: .05))]
      ),
      child: Center(
        child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Container(
            padding: const EdgeInsets.all(Dimensions.paddingSizeCard),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(Dimensions.paddingSizeMediumBorder),
              color: Theme.of(context).primaryColor.withValues(alpha: .12),
            ),
            child: ClipRRect(borderRadius: BorderRadius.circular(Dimensions.paddingSizeMediumBorder),
                child: CustomImageWidget(
                  height: 100,
                  width: 100,
                  image: '${Get.find<SplashController>().configModel?.baseUrls?.productImageUrl}/${product?.image}',
                  fit: BoxFit.cover,
                  placeholder: Images.placeholder,
                ),
            ),
          ),
          const SizedBox(width: Dimensions.paddingSizeSmall),

          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [

                Text(
                  product?.title ?? 'product_name',
                  style: ubuntuRegular.copyWith(color: Theme.of(context).primaryColor),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height:  Dimensions.paddingSizeExtraSmall),

                _CustomProductDetailText(fieldName: 'sku'.tr, textValue: product?.productCode),

              ]),
          )
        ]),
      ),
    );
  }
}

class _CustomProductDetailText extends StatelessWidget {
  final String? fieldName;
  final String? preTextValue;
  final String? textValue;
  const _CustomProductDetailText({this.fieldName, this.preTextValue, this.textValue});

  @override
  Widget build(BuildContext context) {
    return Text.rich(TextSpan(children: [
      TextSpan(text: fieldName ?? '', style: ubuntuRegular.copyWith(color: Theme.of(context).hintColor.withValues(alpha: .7))),

      const TextSpan(text: ' : ', style: ubuntuRegular),

      TextSpan(text: preTextValue ?? '', style: ubuntuRegular),

      TextSpan(text: textValue ?? '', style: ubuntuRegular),
    ]));
  }
}

