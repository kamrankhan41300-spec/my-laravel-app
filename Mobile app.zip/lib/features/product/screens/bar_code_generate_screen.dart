import 'dart:isolate';
import 'dart:ui';
import 'package:barcode_widget/barcode_widget.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:get/get.dart';
import 'package:six_pos/common/models/config_model.dart';
import 'package:six_pos/features/product/controllers/product_controller.dart';
import 'package:six_pos/features/product/widgets/bar_code_product_details_widget.dart';
import 'package:six_pos/features/product/widgets/barcode_generate_reset_button_widget.dart';
import 'package:six_pos/features/product/widgets/barcode_generator_tab_widget.dart';
import 'package:six_pos/features/splash/controllers/splash_controller.dart';
import 'package:six_pos/common/models/product_model.dart';
import 'package:six_pos/helper/extension_helper.dart';
import 'package:six_pos/helper/price_converter_helper.dart';
import 'package:six_pos/helper/responsive_helper.dart';
import 'package:six_pos/util/app_constants.dart';
import 'package:six_pos/util/dimensions.dart';
import 'package:six_pos/util/styles.dart';
import 'package:six_pos/common/widgets/custom_app_bar_widget.dart';
import 'package:six_pos/common/widgets/custom_button_widget.dart';
import 'package:six_pos/common/widgets/custom_drawer_widget.dart';
import 'package:six_pos/common/widgets/custom_header_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class BarCodeGenerateScreen extends StatefulWidget {
  final Products? product;
  const BarCodeGenerateScreen({super.key, this.product});

  @override
  State<BarCodeGenerateScreen> createState() => _BarCodeGenerateScreenState();
}

class _BarCodeGenerateScreenState extends State<BarCodeGenerateScreen> {
  TextEditingController quantityController = TextEditingController();
  final ReceivePort _port = ReceivePort();
  final ConfigModel? configModel = Get.find<SplashController>().configModel;


  bool isLandscape(BuildContext context) {
    return MediaQuery.of(context).orientation == Orientation.landscape;
  }

  @override
  void initState() {
    super.initState();
    quantityController.text = '9';
    IsolateNameServer.registerPortWithName(_port.sendPort, 'downloader_send_port');
    _port.listen((dynamic data) {
      setState((){ });
    });

    FlutterDownloader.registerCallback((id, status, progress) => downloadCallback);
  }

  @override
  void dispose() {
    IsolateNameServer.removePortNameMapping('downloader_send_port');
    super.dispose();
  }

  @pragma('vm:entry-point')
  static void downloadCallback(String id, DownloadTaskStatus status, int progress) {
    final SendPort send = IsolateNameServer.lookupPortByName('downloader_send_port')!;
    send.send([id, status, progress]);
  }




  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: const CustomAppBarWidget(),
      endDrawer:  const CustomDrawerWidget(),
      body: ResponsiveHelper.isTab(context)
          ? BarcodeGeneratorTabWidget(product: widget.product, quantityController: quantityController, configModel: configModel!)
          : GetBuilder<ProductController>(
        builder: (productController) {
          return CustomScrollView(slivers: [

            SliverAppBar(
              automaticallyImplyLeading: false,
              actions: <Widget>[Container()],
              title: CustomHeaderWidget(title: 'bar_code_generator'.tr, fontSize: Dimensions.fontSizeExtraLarge),
              titleSpacing: 0,
              centerTitle: true,
              pinned: true,
              toolbarHeight: 45,
            ),

            SliverToBoxAdapter(child: Container(
              color: Theme.of(context).primaryColor.withValues(alpha: 0.02),
              padding: EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
              child: Column(children: [
                ///Product details card
                BarCodeProductDetailsWidget(product: widget.product),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                ///Generate barcode section
                BarcodeGenerateResetButtonWidget(quantityController: quantityController),
                const SizedBox(height: Dimensions.paddingSizeSmall),

              ]),
            )),

            SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.only(
                    top: Dimensions.paddingSizeDefault, left: Dimensions.paddingSizeLarge,
                    right: Dimensions.paddingSizeDefault ,bottom: Dimensions.paddingSizeSmall,
                ),
                decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Flexible(
                      child: Text(
                        'a4_size_paper'.tr,
                        style: ubuntuMedium.copyWith(
                          color: Theme.of(context).primaryColor,
                          fontSize: Dimensions.fontSizeLarge,
                        ),
                      ),
                    ),

                    Flexible(
                      child: CustomButtonWidget(
                        buttonText: 'download'.tr,
                        onPressed: () async {
                          _launchUrl(Uri.parse('${AppConstants.baseUrl}${AppConstants.barCodeDownload}?id=${widget.product!.id}&quantity=${int.parse(quantityController.text)}'));
                        },
                        buttonColor: Theme.of(context).primaryColor,
                      ),
                    ),
                ]),
              ),
            ),

            // Barcode Grid Section
            SliverPadding(
              padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
              sliver: DecoratedSliver(
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                    boxShadow: [
                      BoxShadow(
                        color: Theme.of(context).hintColor.withValues(alpha: 0.2),
                        blurRadius: 3
                      )
                    ]
                  ),
                sliver: SliverPadding(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: isLandscape(context) ? 3 : 2,
                      mainAxisSpacing: 15,
                      crossAxisSpacing: 15,
                      childAspectRatio: 1.2,
                    ),
                    delegate: SliverChildBuilderDelegate((context, index) {
                      return Container(
                        color: Theme.of(context).cardColor,
                        child: DottedBorder(
                          color: Theme.of(context).hintColor.withValues(alpha: .8),
                          strokeWidth: 1,
                          dashPattern: const [3, 3],
                          padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                          child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [

                            Text(
                              configModel?.businessInfo?.shopName ?? '',
                              style: ubuntuRegular.copyWith(
                                fontSize: Dimensions.fontSizeExtraSmall,
                                color: context.customThemeColors.textColor.withValues(alpha: 0.8),
                              ),
                            ),

                            Column(children: [

                              Text(
                                widget.product?.title ?? '',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: ubuntuBold.copyWith(
                                    fontSize: Dimensions.fontSizeExtraSmall,
                                    color: context.customThemeColors.textColor.withValues(alpha: 0.9)
                                ),
                              ),

                              Text(
                                PriceConverterHelper.symbolWithPrice(
                                  widget.product?.sellingPrice ?? 0,
                                ),
                                style: ubuntuBold.copyWith(
                                    fontSize: Dimensions.fontSizeExtraSmall,
                                    color: context.customThemeColors.textColor.withValues(alpha: 0.9)
                                ),
                              ),

                            ]),

                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
                              child: BarcodeWidget(
                                data: '${'code'.tr} : ${widget.product?.productCode ?? ''}',
                                style: ubuntuRegular,
                                barcode: Barcode.code128(),
                              ),
                            ),
                          ]),
                        ),
                      );
                    },
                      childCount: productController.barCodeQuantity,
                    ),
                  ),
                ),
              ),
            ),
          ]);
        }
      ),
    );
  }
}

Future<void> _launchUrl(Uri url) async {
  if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
    throw 'Could not launch $url';
  }
}
