enum AmountType {
  discount, tax
}